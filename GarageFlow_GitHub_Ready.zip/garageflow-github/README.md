# GarageFlow

**GarageFlow** is a browser-based garage management prototype for managing vehicle repair job cards, repair checklists, spare-parts references, labour charges and customer invoices.

> **Status:** Prototype v0.1 — for demonstrations and collecting customer requirements. Not ready for production garage operations.

## Features

- **Dashboard:** View open and completed jobs and pending tasks.
- **Digital job cards:** Record customer/vehicle details and repair complaints.
- **Repair checklist:** Mark individual complaints complete, and prevent closing a job while any task is pending.
- **Billing:** Add editable labour charges and spare parts, with optional VAT settings.
- **Inventory reference:** Store spare parts, SKUs, stock quantities and default selling prices.
- **Invoices:** Generate invoice numbers and print or save invoices as PDF.
- **Settings and backup:** Configure basic garage details and export/restore JSON backups.

## Run locally

No build tools, dependencies or backend are required.

1. Download or clone this repository.
2. Open `index.html` in Chrome, Edge or Firefox.
3. Explore the included **sample job** and sample inventory items.
4. Enter your own test records and configure the garage details in **Settings**.

## Workflow

1. Create a customer and vehicle job card.
2. Record every reported problem as a separate checklist item.
3. Update individual tasks as repairs are completed.
4. Verify that all repairs are complete before closing the job.
5. Add labour charges and parts, then generate the customer invoice.

## Data storage

This version saves data in the current browser's **localStorage**. It does not synchronize between devices or provide server-side backups. Clearing browser data may remove records; export a JSON backup periodically when testing.

**Do not enter real customer or payment data into this public demonstration or rely on it for operational business records.**

## Known limitations

- No logins, access control, server database or multi-user access.
- Inventory stock is reference-only; adding a part to an invoice does **not** reduce stock levels.
- Generated invoices are not permanently locked; modifying the underlying charges may change an existing invoice.
- The invoice template is generic pending customer review.
- VAT defaults to 0% and must be configured; tax/legal compliance is unverified.
- No payment collection, notifications or automated customer messages.

## Next steps

Confirm the final customer requirements, including invoice layout, tax fields, role permissions, inventory deduction, job approval workflow, reports and multi-device access, before production development.

## License

No open-source license has been selected. Publishing this repository does not automatically grant others rights to use or distribute the code.
